nameInput = {'SWA1.txt', 'SWA2.txt', 'SWA3.txt', 'SWA4.txt', 'SWA5.txt', 'SWA6.txt'};
nameLegend = {'O1', 'O2', 'O3', 'O4', 'O5', 'O6'};

n = length(nameInput);
data = cell(n);

for i =1:n
    data{i} = load(nameInput{i});
end

figure
plot(data{1}(:,1), data{1}(:,2), '-o', 'LineWidth',1); hold on; grid on;
plot(data{2}(:,1), data{2}(:,2), '-o', 'LineWidth',1); hold on; grid on;
plot(data{3}(:,1), data{3}(:,2), '-o', 'LineWidth',1); hold on; grid on;
plot(data{4}(:,1), data{4}(:,2), '-o', 'LineWidth',1); hold on; grid on;
plot(data{5}(:,1), data{5}(:,2), '-o', 'LineWidth',1); hold on; grid on;
plot(data{6}(:,1), data{6}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% for i =2:n
%     plot(data{i}(:,1), data{i}(:,2), '-o');
% end
legend(nameLegend)
% 
% nameInput = {'FWPMM1.txt', 'FWPMM2.txt', 'FWPMM3.txt', 'FWPMM4.txt', 'FWPMM5.txt', 'FWPMM6.txt'};
% nameLegend = {'O1', 'O2', 'O3', 'O4', 'O5', 'O6'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{2}(:,1), data{2}(:,2), '->', 'LineWidth',1); hold on; grid on;
% plot(data{3}(:,1), data{3}(:,2), '--<', 'LineWidth',1); hold on; grid on;
% plot(data{4}(:,1), data{4}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{5}(:,1), data{5}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{6}(:,1), data{6}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% % for i =2:n
% %     plot(data{i}(:,1), data{i}(:,2), '-o');
% % end
% legend(nameLegend)


% nameInput = {'E2SWA1.txt', 'E2SWA2.txt', 'E2SWA3.txt', 'E2SWA4.txt', 'E2SWA5.txt', 'E2SWA6.txt', 'E2SWA7.txt'};
% nameLegend = {'O1', 'O2', 'O3', 'O4', 'O5', 'O6', 'O7'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{2}(:,1), data{2}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{3}(:,1), data{3}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{4}(:,1), data{4}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{5}(:,1), data{5}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{6}(:,1), data{6}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{7}(:,1), data{7}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% % for i =2:n
% %     plot(data{i}(:,1), data{i}(:,2), '-o');
% % end
% legend(nameLegend, 'Location', 'southwest')
% 
% nameInput = {'E2FWPA1.txt', 'E2FWPA2.txt', 'E2FWPA3.txt', 'E2FWPA4.txt', 'E2FWPA5.txt', 'E2FWPA6.txt', 'E2FWPA7.txt'};
% nameLegend = {'O1', 'O2', 'O3', 'O4', 'O5', 'O6', 'O7'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{2}(:,1), data{2}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{3}(:,1), data{3}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{4}(:,1), data{4}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{5}(:,1), data{5}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{6}(:,1), data{6}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{7}(:,1), data{7}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% % for i =2:n
% %     plot(data{i}(:,1), data{i}(:,2), '-o');
% % end
% legend(nameLegend, 'Location', 'southwest')





% nameInput = {'FWPPMM1.txt', 'FWPPMM2.txt', 'FWPPMM3.txt', 'FWPPMM4.txt', 'FWPPMM5.txt', 'FWPPMM6.txt'};
% nameLegend = {'O1', 'O2', 'O3', 'O4', 'O5', 'O6'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{2}(:,1), data{2}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{3}(:,1), data{3}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{4}(:,1), data{4}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{5}(:,1), data{5}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{6}(:,1), data{6}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% % for i =2:n
% %     plot(data{i}(:,1), data{i}(:,2), '-o');
% % end
% legend(nameLegend)







% nameInput = {'E4FWPPA1.txt', 'E4FWPPA2.txt', 'E4FWPPA3.txt', 'E4FWPPA4.txt', 'E4FWPPA5.txt', 'E4FWPPA6.txt', 'E4FWPPA7.txt'};
% nameLegend = {'O1', 'O2', 'O3', 'O4', 'O5', 'O6', 'O7'};
% 
% n = length(nameInput);
% data = cell(n);
% 
% for i =1:n
%     data{i} = load(nameInput{i});
% end
% 
% figure
% plot(data{1}(:,1), data{1}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{2}(:,1), data{2}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{3}(:,1), data{3}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{4}(:,1), data{4}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{5}(:,1), data{5}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{6}(:,1), data{6}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% plot(data{7}(:,1), data{7}(:,2), '-o', 'LineWidth',1); hold on; grid on;
% % for i =2:n
% %     plot(data{i}(:,1), data{i}(:,2), '-o');
% % end
% legend(nameLegend)