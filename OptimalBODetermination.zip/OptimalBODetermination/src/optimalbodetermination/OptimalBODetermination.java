/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package optimalbodetermination;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.DoubleStream;
import java.util.List; 
import java.util.stream.*;
import java.util.*;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 *
 * @author Yuchu Qin & Peizhi Shi
 * @email: qinyuchu@hud.ac.uk
 *         peizhi.shi@manchester.ac.uk
 * @Note:  The codes of the qROFWMM operator were written by Peizhi Shi.
 *         The remaining codes were written by Yuchu Qin.
 *
 */
public class OptimalBODetermination {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // TODO code application logic here
        OptimalBODetermination obod = new OptimalBODetermination();
        
        /*
        //Example 1
        double[] column1 = {18.34, 21.31, 21.31, 20.02, 20.97, 21.90};        
        double[] column2 = {2.88, 3.09, 3.09, 5.11, 4.63, 4.82};                            
        double[] column3 = {105.33, 143.08, 143.08, 271.47, 231.40, 250.10};    
        double[] column4 = {1588.82, 2119.19, 3646.78, 1889.14, 1474.98, 745.22};
        double[] column5 = {2.72, 1.65, 1.65, 1.65, 1.00, 1.00};
                       
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length];
        
        ratio1 = obod.RatioOfNumericalValue(column1);
        ratio2 = obod.RatioOfNumericalValue(column2);
        ratio3 = obod.RatioOfNumericalValue(column3);
        ratio4 = obod.RatioOfNumericalValue(column4);
        ratio5 = obod.RatioOfNumericalValue(column5);
      
        System.out.println("Ratios of Column 1 are as follows:");
        for (int i = 0; i < column1.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio1[i]));
        }
        System.out.println("Ratios of Column 2 are as follows:");
        for (int i = 0; i < column2.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio2[i]));
        }
        System.out.println("Ratios of Column 3 are as follows:");
        for (int i = 0; i < column3.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio3[i]));
        }
        System.out.println("Ratios of Column 4 are as follows:");
        for (int i = 0; i < column4.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio4[i]));
        }
        System.out.println("Ratios of Column 5 are as follows:");
        for (int i = 0; i < column5.length; i++) {
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio5[i]));
        }
        
        double[][][] MM = {
            {{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}, {ratio5[3], 1-ratio5[3]}},
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}, {ratio5[4], 1-ratio5[4]}},
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}, {ratio5[5], 1-ratio5[5]}}
        };
        
        int m = 6;
        int n = 5;
        double q = 1.0;       
        double[] w = {0.2, 0.2, 0.2, 0.2, 0.2};
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP4554 = new double[m];
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][1][0], MM[i][1][1]);
            SUPP1331[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][2][0], MM[i][2][1]);
            SUPP1441[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][3][0], MM[i][3][1]);
            SUPP1551[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][4][0], MM[i][4][1]);
            SUPP2332[i] = 1 - distanceValue(q, MM[i][1][0], MM[i][1][1], MM[i][2][0], MM[i][2][1]);
            SUPP2442[i] = 1 - distanceValue(q, MM[i][1][0], MM[i][1][1], MM[i][3][0], MM[i][3][1]);
            SUPP2552[i] = 1 - distanceValue(q, MM[i][1][0], MM[i][1][1], MM[i][4][0], MM[i][4][1]);
            SUPP3443[i] = 1 - distanceValue(q, MM[i][2][0], MM[i][2][1], MM[i][3][0], MM[i][3][1]);
            SUPP3553[i] = 1 - distanceValue(q, MM[i][2][0], MM[i][2][1], MM[i][4][0], MM[i][4][1]);
            SUPP4554[i] = 1 - distanceValue(q, MM[i][3][0], MM[i][3][1], MM[i][4][0], MM[i][4][1]);
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(SUPP4554[i]));         
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i];
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(TT5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");           
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
              
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w4[i] = (w[3]*(1.0 + TT4[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w5[i] = (w[4]*(1.0 + TT5[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        double[][] www1 = {
            {w1[0],  w5[0]},
            {w1[1],  w5[1]},
            {w1[2],  w5[2]},
            {w1[3],  w5[3]},
            {w1[4],  w5[4]},
            {w1[5],  w5[5]}
        };
        double[][] www2 = {
            {w2[0], w3[0], w4[0]},
            {w2[1], w3[1], w4[1]},
            {w2[2], w3[2], w4[2]},
            {w2[3], w3[3], w4[3]},
            {w2[4], w3[4], w4[4]},
            {w2[5], w3[5], w4[5]}
        };
        
        double[][] rr1 = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rr1[k][r] = 0.0;
            }           
        }
        double[][] rr2 = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rr2[k][r] = 0.0;
            }           
        }     
        double[][] rrr = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rrr[k][r] = 0.0;
            }           
        }
        
        double[][][] MM1 = {
            {{1-ratio1[0], ratio1[0]}, {ratio5[0], 1-ratio5[0]}},
            {{1-ratio1[1], ratio1[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1-ratio1[2], ratio1[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1-ratio1[3], ratio1[3]}, {ratio5[3], 1-ratio5[3]}},
            {{1-ratio1[4], ratio1[4]}, {ratio5[4], 1-ratio5[4]}},
            {{1-ratio1[5], ratio1[5]}, {ratio5[5], 1-ratio5[5]}}
        };
        double[][][] MM2 = {
            {{1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}},
            {{1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}},
            {{1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}},
            {{1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}},
            {{1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}},
            {{1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}}
        };
        
        double[] delta1 = {1.0, 2.0};
        double[] delta2 = {1.0, 2.0, 3.0};
      
        rr1 = obod.qROFWMM(m, 2, q, MM1, www1, delta1);
        rr2 = obod.qROFWMM(m, 3, q, MM2, www2, delta2);
        double[][][] MMMM = {
            {{rr1[0][0], rr1[0][1]}, {rr2[0][0], rr2[0][1]}},
            {{rr1[1][0], rr1[1][1]}, {rr2[1][0], rr2[1][1]}},
            {{rr1[2][0], rr1[2][1]}, {rr2[2][0], rr2[2][1]}},
            {{rr1[3][0], rr1[3][1]}, {rr2[3][0], rr2[3][1]}},
            {{rr1[4][0], rr1[4][1]}, {rr2[4][0], rr2[4][1]}},
            {{rr1[5][0], rr1[5][1]}, {rr2[5][0], rr2[5][1]}}
        };
        
        rrr = obod.qROFPAA(m, 2, q, MMMM);
                                               
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][1]));
        }
        double[] scoreValue = new double[m];                 
        scoreValue = obod.getScoreValue(m, q, rrr);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("Score[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(scoreValue[k]));
        }
        double[] accuracyValue = new double[m];                 
        accuracyValue = obod.getAccuracyValue(m, q, rrr);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("Accuracy[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(accuracyValue[k]));
        }
        
	ArrayIndexComparator comparator = new ArrayIndexComparator(scoreValue, accuracyValue);
	Integer[] indexes = comparator.createIndexArray();
	Arrays.sort(indexes, comparator);
	for(int i = 0; i < indexes.length; i++) {           
            int index = indexes[i]+1;
            System.out.print("A[" + index + "] > ");
        }*/
        
        /*//Example 2
        double[] column1 = {5.40, 3.56, 5.76, 3.85, 8.32, 5.29, 8.35};        
        double[] column2 = {4.32, 4.27, 4.32, 4.27, 6.83, 7.56, 6.79};                            
        double[] column3 = {57.0, 56.0, 57.0, 56.0, 84.0, 92.0, 83.0};    
        double[] column4 = {510.0, 650.0, 712.0, 702.0, 395.0, 652.0, 522.0};
        double[] column5 = {1.65, 2.72, 1.65, 2.72, 0.85, 1.95, 0.85};
                
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length];
        
        ratio1 = obod.RatioOfNumericalValue(column1);
        ratio2 = obod.RatioOfNumericalValue(column2);
        ratio3 = obod.RatioOfNumericalValue(column3);
        ratio4 = obod.RatioOfNumericalValue(column4);
        ratio5 = obod.RatioOfNumericalValue(column5);
      
        System.out.println("Ratios of Column 1 are as follows:");
        for (int i = 0; i < column1.length; i++) {
            System.out.print("{" + new java.text.DecimalFormat("#0.0000").format(1-ratio1[i]) + ", ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio1[i]) + "}");
        }
        System.out.println("Ratios of Column 2 are as follows:");
        for (int i = 0; i < column2.length; i++) {
            System.out.print("{" + new java.text.DecimalFormat("#0.0000").format(1-ratio2[i]) + ", ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio2[i]) + "}");
        }
        System.out.println("Ratios of Column 3 are as follows:");
        for (int i = 0; i < column3.length; i++) {
            System.out.print("{" + new java.text.DecimalFormat("#0.0000").format(1-ratio3[i]) + ", ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio3[i]) + "}");
        }
        System.out.println("Ratios of Column 4 are as follows:");
        for (int i = 0; i < column4.length; i++) {
            System.out.print("{" + new java.text.DecimalFormat("#0.0000").format(1-ratio4[i]) + ", ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(ratio4[i]) + "}");
        }
        System.out.println("Ratios of Column 5 are as follows:");
        for (int i = 0; i < column5.length; i++) {
            System.out.print("{" + new java.text.DecimalFormat("#0.0000").format(ratio5[i]) + ", ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(1-ratio5[i]) + "}");
        }
        
        //double[][][] MN = {
            //{{1.0000, 0.0000}, {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000}},
            //{{1.0000, 0.0000}, {1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},
            //{{1.0000, 0.0000}, {1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}, {ratio5[1], 1-ratio5[1]}},
            //{{1.0000, 0.0000}, {1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}, {ratio5[2], 1-ratio5[2]}},
            //{{1.0000, 0.0000}, {1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}, {ratio5[3], 1-ratio5[3]}},
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}, {ratio5[4], 1-ratio5[4]}},
            //{{1.0000, 0.0000}, {1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}, {ratio5[5], 1-ratio5[5]}},
            //{{1.0000, 0.0000}, {1-ratio1[6], ratio1[6]}, {1-ratio2[6], ratio2[6]}, {1-ratio3[6], ratio3[6]}, {1-ratio4[6], ratio4[6]}, {ratio5[6], 1-ratio5[6]}}
        //};
        
        double[][][] MMM = {
            {{1.0000, 0.0000}, {1.0000, 0.0000}, {1.0000, 0.0000}, {1.0000, 0.0000}, {1.0000, 0.0000}, {1.0000, 0.0000}},
            {{1.0000, 0.0000}, {0.6630, 0.3370}, {0.7112, 0.2888}, {0.6961, 0.3039}, {0.6797, 0.3203}, {0.3268, 0.6732}},
            {{1.0000, 0.0000}, {0.7778, 0.2222}, {0.7145, 0.2855}, {0.7014, 0.2986}, {0.5918, 0.4082}, {0.5388, 0.4612}},
            {{1.0000, 0.0000}, {0.6405, 0.3595}, {0.7112, 0.2888}, {0.6961, 0.3039}, {0.5529, 0.4471}, {0.3268, 0.6732}},
            {{1.0000, 0.0000}, {0.7597, 0.2403}, {0.7145, 0.2855}, {0.7014, 0.2986}, {0.5592, 0.4408}, {0.5388, 0.4612}},
            {{1.0000, 0.0000}, {0.4808, 0.5192}, {0.5433, 0.4567}, {0.5521, 0.4479}, {0.7520, 0.2480}, {0.1684, 0.8316}},
            {{1.0000, 0.0000}, {0.6699, 0.3301}, {0.4945, 0.5055}, {0.5095, 0.4905}, {0.5906, 0.4094}, {0.3862, 0.6138}},
            {{1.0000, 0.0000}, {0.4789, 0.5211}, {0.5460, 0.4540}, {0.5575, 0.4425}, {0.6722, 0.3278}, {0.1684, 0.8316}}
        };
             
        int m = 8;
        int n = 6;
        double q = 1.0;
        double[] w = {0.0000, 0.125, 0.125, 0.125, 0.5000, 0.125};
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP4554 = new double[m];
        for (int i = 1; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][2][0], MMM[i][2][1]);
            SUPP1331[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][3][0], MMM[i][3][1]);
            SUPP1441[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][4][0], MMM[i][4][1]);
            SUPP1551[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][5][0], MMM[i][5][1]);
            SUPP2332[i] = 1 - distanceValue(q, MMM[i][2][0], MMM[i][2][1], MMM[i][3][0], MMM[i][3][1]);
            SUPP2442[i] = 1 - distanceValue(q, MMM[i][2][0], MMM[i][2][1], MMM[i][4][0], MMM[i][4][1]);
            SUPP2552[i] = 1 - distanceValue(q, MMM[i][2][0], MMM[i][2][1], MMM[i][5][0], MMM[i][5][1]);
            SUPP3443[i] = 1 - distanceValue(q, MMM[i][3][0], MMM[i][3][1], MMM[i][4][0], MMM[i][4][1]);
            SUPP3553[i] = 1 - distanceValue(q, MMM[i][3][0], MMM[i][3][1], MMM[i][5][0], MMM[i][5][1]);
            SUPP4554[i] = 1 - distanceValue(q, MMM[i][4][0], MMM[i][4][1], MMM[i][5][0], MMM[i][5][1]);
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(SUPP3443[i]));         
        }
        
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        for (int i = 1; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i];
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(TT4[i]));           
        }
                   
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
               
        for (int i = 1; i < m; i++) {     
            w1[i] = (w[1]*(1.0 + TT1[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w2[i] = (w[2]*(1.0 + TT2[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w3[i] = (w[3]*(1.0 + TT3[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w4[i] = (w[4]*(1.0 + TT4[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w5[i] = (w[5]*(1.0 + TT5[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w1[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w2[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w3[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w4[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));
        }
        
        double[][] www = {
            {1.000, 1.000, 1.000, 1.000, 1.000, 1.000},
            {1.000, w1[1], w2[1], w3[1], w4[1], w5[1]},
            {1.000, w1[2], w2[2], w3[2], w4[2], w5[2]},
            {1.000, w1[3], w2[3], w3[3], w4[3], w5[3]},
            {1.000, w1[4], w2[4], w3[4], w4[4], w5[4]},
            {1.000, w1[5], w2[5], w3[5], w4[5], w5[5]},
            {1.000, w1[6], w2[6], w3[6], w4[6], w5[6]},
            {1.000, w1[7], w2[7], w3[7], w4[7], w5[7]}
        };
        
        double[] t1x1 = {1.0, 0.0};
        double[] t2x1 = {0.6797, 0.3203};
        double[] t3x1 = {0.4834, 0.5166};
        double[] FN11 = {0.0, 0.0};
        double[] FN12 = {0.0, 0.0};
        double[] FN13 = {0.0, 0.0};
        double[] FN1 = {0.0, 0.0};
        FN11 = FNmFN(1.0, t1x1, RNmFN(1.0, www[1][4], MMM[1][4]));       
        FN12 = FNmFN(1.0, t2x1, FNpFN(1.0, RNmFN(1.0, www[1][2], MMM[1][2]), RNmFN(1.0, www[1][3], MMM[1][3])));
        FN13 = FNmFN(1.0, t3x1, FNpFN(1.0, RNmFN(1.0, www[1][1], MMM[1][1]), RNmFN(1.0, www[1][5], MMM[1][5])));
        FN1 = FNpFN(1.0, FNpFN(1.0, FN11, FN12), FN13);
        System.out.println("FN1 = <" + new java.text.DecimalFormat("#0.0000").format(FN1[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN1[1]) + ">");
        System.out.println("S1 = " + new java.text.DecimalFormat("#0.0000").format(FN1[0]-FN1[1]));
        
        double[] t1x2 = {1.0, 0.0};
        double[] t2x2 = {0.5918, 0.4082};
        double[] t3x2 = {0.2416, 0.7584};
        double[] FN21 = {0.0, 0.0};
        double[] FN22 = {0.0, 0.0};
        double[] FN23 = {0.0, 0.0};
        double[] FN2 = {0.0, 0.0};
        FN21 = FNmFN(1.0, t1x2, RNmFN(1.0, www[2][4], MMM[2][4]));       
        FN22 = FNmFN(1.0, t2x2, FNpFN(1.0, RNmFN(1.0, www[2][2], MMM[2][2]), RNmFN(1.0, www[2][3], MMM[2][3])));
        FN23 = FNmFN(1.0, t3x2, FNpFN(1.0, RNmFN(1.0, www[2][1], MMM[2][1]), RNmFN(1.0, www[2][5], MMM[2][5])));
        FN2 = FNpFN(1.0, FNpFN(1.0, FN21, FN22), FN23);
        System.out.println("FN2 = <" + new java.text.DecimalFormat("#0.0000").format(FN2[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN2[1]) + ">");
        System.out.println("S2 = " + new java.text.DecimalFormat("#0.0000").format(FN2[0]-FN2[1]));
        
        double[] t1x3 = {1.0, 0.0};
        double[] t2x3 = {0.5529, 0.4471};
        double[] t3x3 = {0.3932, 0.6068};
        double[] FN31 = {0.0, 0.0};
        double[] FN32 = {0.0, 0.0};
        double[] FN33 = {0.0, 0.0};
        double[] FN3 = {0.0, 0.0};
        FN31 = FNmFN(1.0, t1x3, RNmFN(1.0, www[3][4], MMM[3][4]));       
        FN32 = FNmFN(1.0, t2x3, FNpFN(1.0, RNmFN(1.0, www[3][2], MMM[3][2]), RNmFN(1.0, www[3][3], MMM[3][3])));
        FN33 = FNmFN(1.0, t3x3, FNpFN(1.0, RNmFN(1.0, www[3][1], MMM[3][1]), RNmFN(1.0, www[3][5], MMM[3][5])));
        FN3 = FNpFN(1.0, FNpFN(1.0, FN31, FN32), FN33);
        System.out.println("FN3 = <" + new java.text.DecimalFormat("#0.0000").format(FN3[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN3[1]) + ">");
        System.out.println("S3 = " + new java.text.DecimalFormat("#0.0000").format(FN3[0]-FN3[1]));
        
        double[] t1x4 = {1.0, 0.0};
        double[] t2x4 = {0.5592, 0.4408};
        double[] t3x4 = {0.3995, 0.6005};
        double[] FN41 = {0.0, 0.0};
        double[] FN42 = {0.0, 0.0};
        double[] FN43 = {0.0, 0.0};
        double[] FN4 = {0.0, 0.0};
        FN41 = FNmFN(1.0, t1x4, RNmFN(1.0, www[4][4], MMM[4][4]));       
        FN42 = FNmFN(1.0, t2x4, FNpFN(1.0, RNmFN(1.0, www[4][2], MMM[4][2]), RNmFN(1.0, www[4][3], MMM[4][3])));
        FN43 = FNmFN(1.0, t3x4, FNpFN(1.0, RNmFN(1.0, www[4][1], MMM[4][1]), RNmFN(1.0, www[4][5], MMM[4][5])));
        FN4 = FNpFN(1.0, FNpFN(1.0, FN41, FN42), FN43);
        System.out.println("FN4 = <" + new java.text.DecimalFormat("#0.0000").format(FN4[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN4[1]) + ">");
        System.out.println("S4 = " + new java.text.DecimalFormat("#0.0000").format(FN4[0]-FN4[1]));
        
        double[] t1x5 = {1.0, 0.0};
        double[] t2x5 = {0.7520, 0.2480};
        double[] t3x5 = {0.4152, 0.5848};
        double[] FN51 = {0.0, 0.0};
        double[] FN52 = {0.0, 0.0};
        double[] FN53 = {0.0, 0.0};
        double[] FN5 = {0.0, 0.0};
        FN51 = FNmFN(1.0, t1x5, RNmFN(1.0, www[5][4], MMM[5][4]));       
        FN52 = FNmFN(1.0, t2x5, FNpFN(1.0, RNmFN(1.0, www[5][2], MMM[5][2]), RNmFN(1.0, www[5][3], MMM[5][3])));
        FN53 = FNmFN(1.0, t3x5, FNpFN(1.0, RNmFN(1.0, www[5][1], MMM[5][1]), RNmFN(1.0, www[5][5], MMM[5][5])));
        FN5 = FNpFN(1.0, FNpFN(1.0, FN51, FN52), FN53);
        System.out.println("FN5 = <" + new java.text.DecimalFormat("#0.0000").format(FN5[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN5[1]) + ">");
        System.out.println("S5 = " + new java.text.DecimalFormat("#0.0000").format(FN5[0]-FN5[1]));
        
        double[] t1x6 = {1.0, 0.0};
        double[] t2x6 = {0.5906, 0.4094};
        double[] t3x6 = {0.3009, 0.6991};
        double[] FN61 = {0.0, 0.0};
        double[] FN62 = {0.0, 0.0};
        double[] FN63 = {0.0, 0.0};
        double[] FN6 = {0.0, 0.0};
        FN61 = FNmFN(1.0, t1x6, RNmFN(1.0, www[6][4], MMM[6][4]));       
        FN62 = FNmFN(1.0, t2x6, FNpFN(1.0, RNmFN(1.0, www[6][2], MMM[6][2]), RNmFN(1.0, www[6][3], MMM[6][3])));
        FN63 = FNmFN(1.0, t3x6, FNpFN(1.0, RNmFN(1.0, www[6][1], MMM[6][1]), RNmFN(1.0, www[6][5], MMM[6][5])));
        FN6 = FNpFN(1.0, FNpFN(1.0, FN61, FN62), FN63);
        System.out.println("FN6 = <" + new java.text.DecimalFormat("#0.0000").format(FN6[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN6[1]) + ">");
        System.out.println("S6 = " + new java.text.DecimalFormat("#0.0000").format(FN6[0]-FN6[1]));
        
        double[] t1x7 = {1.0, 0.0};
        double[] t2x7 = {0.6722, 0.3278};
        double[] t3x7 = {0.3748, 0.6252};
        double[] FN71 = {0.0, 0.0};
        double[] FN72 = {0.0, 0.0};
        double[] FN73 = {0.0, 0.0};
        double[] FN7 = {0.0, 0.0};
        FN71 = FNmFN(1.0, t1x7, RNmFN(1.0, www[7][4], MMM[7][4]));       
        FN72 = FNmFN(1.0, t2x7, FNpFN(1.0, RNmFN(1.0, www[7][2], MMM[7][2]), RNmFN(1.0, www[7][3], MMM[7][3])));
        FN73 = FNmFN(1.0, t3x7, FNpFN(1.0, RNmFN(1.0, www[7][1], MMM[7][1]), RNmFN(1.0, www[7][5], MMM[7][5])));
        FN7 = FNpFN(1.0, FNpFN(1.0, FN71, FN72), FN73);
        System.out.println("FN7 = <" + new java.text.DecimalFormat("#0.0000").format(FN7[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN7[1]) + ">");
        System.out.println("S7 = " + new java.text.DecimalFormat("#0.0000").format(FN7[0]-FN7[1]));
        
        int mmm = 7;       
        double qqq = 1.0;        
        
        double[][] rrr = {
            {FN1[0], FN1[1]},
            {FN2[0], FN2[1]},
            {FN3[0], FN3[1]},
            {FN4[0], FN4[1]},
            {FN5[0], FN5[1]},
            {FN6[0], FN6[1]},
            {FN7[0], FN7[1]}
        };
        
        double[] scoreValue = new double[mmm];                 
        scoreValue = obod.getScoreValue(mmm, qqq, rrr);
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("Score[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(scoreValue[k]));
        }
        double[] accuracyValue = new double[mmm];                 
        accuracyValue = obod.getAccuracyValue(mmm, qqq, rrr);
        for (int k = 0; k < mmm; k++) { 
            int index = k + 1;
            System.out.println("Accuracy[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(accuracyValue[k]));
        }
        
	ArrayIndexComparator comparator = new ArrayIndexComparator(scoreValue, accuracyValue);
	Integer[] indexes = comparator.createIndexArray();
	Arrays.sort(indexes, comparator);
	for(int i = 0; i < indexes.length; i++) {           
            int index = indexes[i]+1;
            System.out.print("A[" + index + "] > ");
        }*/
        
        /*
        //Experiment 1
        double[] column1 = {18.34, 21.31, 21.31, 20.02, 20.97, 21.90};        
        double[] column2 = {2.88, 3.09, 3.09, 5.11, 4.63, 4.82};                            
        double[] column3 = {105.33, 143.08, 143.08, 271.47, 231.40, 250.10};    
        double[] column4 = {2.72, 1.65, 1.65, 1.65, 1.00, 1.00};
        
                       
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        
        ratio1 = obod.RatioOfNumericalValue(column1);
        ratio2 = obod.RatioOfNumericalValue(column2);
        ratio3 = obod.RatioOfNumericalValue(column3);
        ratio4 = obod.RatioOfNumericalValue(column4);
            
     
        double[][][] MM = {
            {{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {ratio4[0], 1-ratio4[0]}},//0
            //{{1-ratio1[0], ratio1[0]}, {0.7093, 0.2907}, {0.7858, 0.2142}, {ratio4[0], 1-ratio4[0]}},//0
            //{{1-ratio1[0], ratio1[0]}, {0.6093, 0.3907}, {0.6858, 0.3142}, {ratio4[0], 1-ratio4[0]}},//1
            //{{1-ratio1[0], ratio1[0]}, {0.5093, 0.4907}, {0.5858, 0.4142}, {ratio4[0], 1-ratio4[0]}},//2
            //{{1-ratio1[0], ratio1[0]}, {0.4093, 0.5907}, {0.4858, 0.5142}, {ratio4[0], 1-ratio4[0]}},//3
            //{{1-ratio1[0], ratio1[0]}, {0.3093, 0.6907}, {0.3858, 0.6142}, {ratio4[0], 1-ratio4[0]}},//4
            //{{1-ratio1[0], ratio1[0]}, {0.2093, 0.7907}, {0.2858, 0.7142}, {ratio4[0], 1-ratio4[0]}},//5
            //{{1-ratio1[0], ratio1[0]}, {0.1093, 0.8907}, {0.1858, 0.8142}, {ratio4[0], 1-ratio4[0]}},//6
            //{{1-ratio1[0], ratio1[0]}, {0.0093, 0.9907}, {0.0858, 0.9142}, {ratio4[0], 1-ratio4[0]}},//7
            
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {ratio4[1], 1-ratio4[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {ratio4[2], 1-ratio4[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {ratio4[3], 1-ratio4[3]}},
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {ratio4[4], 1-ratio4[4]}},
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {ratio4[5], 1-ratio4[5]}}
        };
        double[][][] MM1 = {
            {{1-ratio1[0], ratio1[0]}, {ratio4[0], 1-ratio4[0]}},
            {{1-ratio1[1], ratio1[1]}, {ratio4[1], 1-ratio4[1]}},
            {{1-ratio1[2], ratio1[2]}, {ratio4[2], 1-ratio4[2]}},
            {{1-ratio1[3], ratio1[3]}, {ratio4[3], 1-ratio4[3]}},
            {{1-ratio1[4], ratio1[4]}, {ratio4[4], 1-ratio4[4]}},
            {{1-ratio1[5], ratio1[5]}, {ratio4[5], 1-ratio4[5]}}
        };
        double[][][] MM2 = {
            {{1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}},//0            
            //{{0.7093, 0.2907}, {0.7858, 0.2142}},//0
            //{{0.6093, 0.3907}, {0.6858, 0.3142}},//1
            //{{0.5093, 0.4907}, {0.5858, 0.4142}},//2
            //{{0.4093, 0.5907}, {0.4858, 0.5142}},//3
            //{{0.3093, 0.6907}, {0.3858, 0.6142}},//4
            //{{0.2093, 0.7907}, {0.2858, 0.7142}},//5
            //{{0.1093, 0.8907}, {0.1858, 0.8142}},//6
            //{{0.0093, 0.9907}, {0.0858, 0.9142}},//7
            
            {{1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}},
            {{1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}},
            {{1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}},
            {{1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}},
            {{1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}}
        };
        
        
        int m = 6;
        int n = 4;
        double q = 1.0;       
        double[] w = {0.25, 0.25, 0.25, 0.25};
        
        double[][] rOfSWA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rOfSWA[k][r] = 0.0;
            }           
        }
        
        rOfSWA = obod.qROFSWA(m, n, MM, w);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rOfSWA[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rOfSWA[k][1]));
        }
        
        File fileWrite11 = new File("SWA1.txt");
        BufferedWriter writer11 = new BufferedWriter(new FileWriter(fileWrite11, true)); 
        File fileWrite12 = new File("SWA2.txt");
        BufferedWriter writer12 = new BufferedWriter(new FileWriter(fileWrite12, true));
        File fileWrite13 = new File("SWA3.txt");
        BufferedWriter writer13 = new BufferedWriter(new FileWriter(fileWrite13, true));
        File fileWrite14 = new File("SWA4.txt");
        BufferedWriter writer14 = new BufferedWriter(new FileWriter(fileWrite14, true)); 
        File fileWrite15 = new File("SWA5.txt");
        BufferedWriter writer15 = new BufferedWriter(new FileWriter(fileWrite15, true));  
        File fileWrite16 = new File("SWA6.txt");
        BufferedWriter writer16 = new BufferedWriter(new FileWriter(fileWrite16, true));  
        
        writer11.write(String.valueOf(rOfSWA[0][0]) + "\r\n");
        writer12.write(String.valueOf(rOfSWA[1][0]) + "\r\n");
        writer13.write(String.valueOf(rOfSWA[2][0]) + "\r\n");
        writer14.write(String.valueOf(rOfSWA[3][0]) + "\r\n");
        writer15.write(String.valueOf(rOfSWA[4][0]) + "\r\n");
        writer16.write(String.valueOf(rOfSWA[5][0]) + "\r\n");
        writer11.close();
        writer12.close();
        writer13.close();
        writer14.close();
        writer15.close();
        writer16.close();
        
        double[][] rr1 = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rr1[k][r] = 0.0;
            }           
        }
        double[][] rr2 = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rr2[k][r] = 0.0;
            }           
        }     
        double[][] rrr = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rrr[k][r] = 0.0;
            }           
        }                   
        
        double[] www1 = {0.25, 0.25};
        double[] www2 = {0.25, 0.25};
        double[] delta1 = {1.0, 2.0};
        double[] delta2 = {1.0, 2.0};
      
        rr1 = obod.qROFWMM1(m, 2, q, MM1, www1, delta1);
        rr2 = obod.qROFWMM1(m, 2, q, MM2, www2, delta2);
        double[][][] MMMM = {
            {{rr1[0][0], rr1[0][1]}, {rr2[0][0], rr2[0][1]}},
            {{rr1[1][0], rr1[1][1]}, {rr2[1][0], rr2[1][1]}},
            {{rr1[2][0], rr1[2][1]}, {rr2[2][0], rr2[2][1]}},
            {{rr1[3][0], rr1[3][1]}, {rr2[3][0], rr2[3][1]}},
            {{rr1[4][0], rr1[4][1]}, {rr2[4][0], rr2[4][1]}},
            {{rr1[5][0], rr1[5][1]}, {rr2[5][0], rr2[5][1]}}
        };
        
        rrr = obod.qROFPAA(m, 2, q, MMMM);
                                               
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][1]));
        }
        
        File fileWrite21 = new File("FWPMM1.txt");
        BufferedWriter writer21 = new BufferedWriter(new FileWriter(fileWrite21, true)); 
        File fileWrite22 = new File("FWPMM2.txt");
        BufferedWriter writer22 = new BufferedWriter(new FileWriter(fileWrite22, true));
        File fileWrite23 = new File("FWPMM3.txt");
        BufferedWriter writer23 = new BufferedWriter(new FileWriter(fileWrite23, true));
        File fileWrite24 = new File("FWPMM4.txt");
        BufferedWriter writer24 = new BufferedWriter(new FileWriter(fileWrite24, true)); 
        File fileWrite25 = new File("FWPMM5.txt");
        BufferedWriter writer25 = new BufferedWriter(new FileWriter(fileWrite25, true));  
        File fileWrite26 = new File("FWPMM6.txt");
        BufferedWriter writer26 = new BufferedWriter(new FileWriter(fileWrite26, true));  
        
        writer21.write(String.valueOf(rrr[0][0]) + "\r\n");
        writer22.write(String.valueOf(rrr[1][0]) + "\r\n");
        writer23.write(String.valueOf(rrr[2][0]) + "\r\n");
        writer24.write(String.valueOf(rrr[3][0]) + "\r\n");
        writer25.write(String.valueOf(rrr[4][0]) + "\r\n");
        writer26.write(String.valueOf(rrr[5][0]) + "\r\n");
        writer21.close();
        writer22.close();
        writer23.close();
        writer24.close();
        writer25.close();
        writer26.close();    */
        
        /*//Experiment 2
        double[] column1 = {5.40, 3.56, 5.76, 3.85, 8.32, 5.29, 8.35};        
        double[] column2 = {4.32, 4.27, 4.32, 4.27, 6.83, 7.56, 6.79};                            
        double[] column3 = {57.0, 56.0, 57.0, 56.0, 84.0, 92.0, 83.0};    
        double[] column4 = {510.0, 650.0, 712.0, 702.0, 395.0, 652.0, 522.0};
        double[] column5 = {1.65, 2.72, 1.65, 2.72, 0.85, 1.95, 0.85};
                
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length];
        
        ratio1 = obod.RatioOfNumericalValue(column1);
        ratio2 = obod.RatioOfNumericalValue(column2);
        ratio3 = obod.RatioOfNumericalValue(column3);
        ratio4 = obod.RatioOfNumericalValue(column4);
        ratio5 = obod.RatioOfNumericalValue(column5);
        
        double[][][] MN = {                  
            {{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}, {ratio5[3], 1-ratio5[3]}},
            
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}, {ratio5[4], 1-ratio5[4]}},//0
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.7520, 0.2480}, {ratio5[4], 1-ratio5[4]}},//0
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.7220, 0.2780}, {ratio5[4], 1-ratio5[4]}},//1
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6920, 0.3080}, {ratio5[4], 1-ratio5[4]}},//2
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6620, 0.3380}, {ratio5[4], 1-ratio5[4]}},//3
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6320, 0.3680}, {ratio5[4], 1-ratio5[4]}},//4
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6020, 0.3980}, {ratio5[4], 1-ratio5[4]}},//5
            //{{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.5720, 0.4280}, {ratio5[4], 1-ratio5[4]}},//6
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.5420, 0.4580}, {ratio5[4], 1-ratio5[4]}},//7
            
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}, {ratio5[5], 1-ratio5[5]}},
            {{1-ratio1[6], ratio1[6]}, {1-ratio2[6], ratio2[6]}, {1-ratio3[6], ratio3[6]}, {1-ratio4[6], ratio4[6]}, {ratio5[6], 1-ratio5[6]}}
        };
        int m = 7;
        int n = 5;
        double q = 1.0;
        double[] w = {0.125, 0.125, 0.125, 0.500, 0.125};
        double[][] rOfSWA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rOfSWA[k][r] = 0.0;
            }           
        }
        
        rOfSWA = obod.qROFSWA(m, n, MN, w);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rOfSWA[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rOfSWA[k][1]));
        }
        
        File fileWrite11 = new File("E2SWA1.txt");
        BufferedWriter writer11 = new BufferedWriter(new FileWriter(fileWrite11, true)); 
        File fileWrite12 = new File("E2SWA2.txt");
        BufferedWriter writer12 = new BufferedWriter(new FileWriter(fileWrite12, true));
        File fileWrite13 = new File("E2SWA3.txt");
        BufferedWriter writer13 = new BufferedWriter(new FileWriter(fileWrite13, true));
        File fileWrite14 = new File("E2SWA4.txt");
        BufferedWriter writer14 = new BufferedWriter(new FileWriter(fileWrite14, true)); 
        File fileWrite15 = new File("E2SWA5.txt");
        BufferedWriter writer15 = new BufferedWriter(new FileWriter(fileWrite15, true));  
        File fileWrite16 = new File("E2SWA6.txt");
        BufferedWriter writer16 = new BufferedWriter(new FileWriter(fileWrite16, true));
        File fileWrite17 = new File("E2SWA7.txt");
        BufferedWriter writer17 = new BufferedWriter(new FileWriter(fileWrite17, true));
        
        writer11.write(String.valueOf(rOfSWA[0][0]) + "\r\n");
        writer12.write(String.valueOf(rOfSWA[1][0]) + "\r\n");
        writer13.write(String.valueOf(rOfSWA[2][0]) + "\r\n");
        writer14.write(String.valueOf(rOfSWA[3][0]) + "\r\n");
        writer15.write(String.valueOf(rOfSWA[4][0]) + "\r\n");
        writer16.write(String.valueOf(rOfSWA[5][0]) + "\r\n");
        writer17.write(String.valueOf(rOfSWA[6][0]) + "\r\n");
        writer11.close();
        writer12.close();
        writer13.close();
        writer14.close();
        writer15.close();
        writer16.close();
        writer17.close();
        
        double[][][] MMM = {
            {{1.0000, 0.0000}, {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000}},
            {{1.0000, 0.0000}, {1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},
            {{1.0000, 0.0000}, {1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1.0000, 0.0000}, {1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1.0000, 0.0000}, {1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}, {ratio5[3], 1-ratio5[3]}},
            
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}, {ratio5[4], 1-ratio5[4]}},//0
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.7520, 0.2480}, {ratio5[4], 1-ratio5[4]}},//0
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.7220, 0.2780}, {ratio5[4], 1-ratio5[4]}},//1
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6920, 0.3080}, {ratio5[4], 1-ratio5[4]}},//2
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6620, 0.3380}, {ratio5[4], 1-ratio5[4]}},//3
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6320, 0.3680}, {ratio5[4], 1-ratio5[4]}},//4
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6020, 0.3980}, {ratio5[4], 1-ratio5[4]}},//5
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.5720, 0.4280}, {ratio5[4], 1-ratio5[4]}},//6
            {{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.5420, 0.4580}, {ratio5[4], 1-ratio5[4]}},//7
            
            {{1.0000, 0.0000}, {1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}, {ratio5[5], 1-ratio5[5]}},
            {{1.0000, 0.0000}, {1-ratio1[6], ratio1[6]}, {1-ratio2[6], ratio2[6]}, {1-ratio3[6], ratio3[6]}, {1-ratio4[6], ratio4[6]}, {ratio5[6], 1-ratio5[6]}}
        };
        double[] www = {0.000, 0.125, 0.125, 0.125, 0.500, 0.125};
        
        double[] t1x1 = {1.0, 0.0};
        double[] t2x1 = {0.6797, 0.3203};
        double[] t3x1 = {0.4834, 0.5166};
        double[] FN11 = {0.0, 0.0};
        double[] FN12 = {0.0, 0.0};
        double[] FN13 = {0.0, 0.0};
        double[] FN1 = {0.0, 0.0};
        FN11 = FNmFN(1.0, t1x1, RNmFN(1.0, www[4], MMM[1][4]));       
        FN12 = FNmFN(1.0, t2x1, FNpFN(1.0, RNmFN(1.0, www[2], MMM[1][2]), RNmFN(1.0, www[3], MMM[1][3])));
        FN13 = FNmFN(1.0, t3x1, FNpFN(1.0, RNmFN(1.0, www[1], MMM[1][1]), RNmFN(1.0, www[5], MMM[1][5])));
        FN1 = FNpFN(1.0, FNpFN(1.0, FN11, FN12), FN13);
        System.out.println("FN1 = <" + new java.text.DecimalFormat("#0.0000").format(FN1[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN1[1]) + ">");
        
        
        double[] t1x2 = {1.0, 0.0};
        double[] t2x2 = {0.5918, 0.4082};
        double[] t3x2 = {0.2416, 0.7584};
        double[] FN21 = {0.0, 0.0};
        double[] FN22 = {0.0, 0.0};
        double[] FN23 = {0.0, 0.0};
        double[] FN2 = {0.0, 0.0};
        FN21 = FNmFN(1.0, t1x2, RNmFN(1.0, www[4], MMM[2][4]));       
        FN22 = FNmFN(1.0, t2x2, FNpFN(1.0, RNmFN(1.0, www[2], MMM[2][2]), RNmFN(1.0, www[3], MMM[2][3])));
        FN23 = FNmFN(1.0, t3x2, FNpFN(1.0, RNmFN(1.0, www[1], MMM[2][1]), RNmFN(1.0, www[5], MMM[2][5])));
        FN2 = FNpFN(1.0, FNpFN(1.0, FN21, FN22), FN23);
        System.out.println("FN2 = <" + new java.text.DecimalFormat("#0.0000").format(FN2[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN2[1]) + ">");
        
        
        double[] t1x3 = {1.0, 0.0};
        double[] t2x3 = {0.5529, 0.4471};
        double[] t3x3 = {0.3932, 0.6068};
        double[] FN31 = {0.0, 0.0};
        double[] FN32 = {0.0, 0.0};
        double[] FN33 = {0.0, 0.0};
        double[] FN3 = {0.0, 0.0};
        FN31 = FNmFN(1.0, t1x3, RNmFN(1.0, www[4], MMM[3][4]));       
        FN32 = FNmFN(1.0, t2x3, FNpFN(1.0, RNmFN(1.0, www[2], MMM[3][2]), RNmFN(1.0, www[3], MMM[3][3])));
        FN33 = FNmFN(1.0, t3x3, FNpFN(1.0, RNmFN(1.0, www[1], MMM[3][1]), RNmFN(1.0, www[5], MMM[3][5])));
        FN3 = FNpFN(1.0, FNpFN(1.0, FN31, FN32), FN33);
        System.out.println("FN3 = <" + new java.text.DecimalFormat("#0.0000").format(FN3[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN3[1]) + ">");
        
        
        double[] t1x4 = {1.0, 0.0};
        double[] t2x4 = {0.5592, 0.4408};
        double[] t3x4 = {0.3995, 0.6005};
        double[] FN41 = {0.0, 0.0};
        double[] FN42 = {0.0, 0.0};
        double[] FN43 = {0.0, 0.0};
        double[] FN4 = {0.0, 0.0};
        FN41 = FNmFN(1.0, t1x4, RNmFN(1.0, www[4], MMM[4][4]));       
        FN42 = FNmFN(1.0, t2x4, FNpFN(1.0, RNmFN(1.0, www[2], MMM[4][2]), RNmFN(1.0, www[3], MMM[4][3])));
        FN43 = FNmFN(1.0, t3x4, FNpFN(1.0, RNmFN(1.0, www[1], MMM[4][1]), RNmFN(1.0, www[5], MMM[4][5])));
        FN4 = FNpFN(1.0, FNpFN(1.0, FN41, FN42), FN43);
        System.out.println("FN4 = <" + new java.text.DecimalFormat("#0.0000").format(FN4[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN4[1]) + ">");
        
        
        double[] t1x5 = {1.0, 0.0};
        double[] t2x5 = {0.7520, 0.2480};
        double[] t3x5 = {0.4152, 0.5848};
        double[] FN51 = {0.0, 0.0};
        double[] FN52 = {0.0, 0.0};
        double[] FN53 = {0.0, 0.0};
        double[] FN5 = {0.0, 0.0};
        FN51 = FNmFN(1.0, t1x5, RNmFN(1.0, www[4], MMM[5][4]));       
        FN52 = FNmFN(1.0, t2x5, FNpFN(1.0, RNmFN(1.0, www[2], MMM[5][2]), RNmFN(1.0, www[3], MMM[5][3])));
        FN53 = FNmFN(1.0, t3x5, FNpFN(1.0, RNmFN(1.0, www[1], MMM[5][1]), RNmFN(1.0, www[5], MMM[5][5])));
        FN5 = FNpFN(1.0, FNpFN(1.0, FN51, FN52), FN53);
        System.out.println("FN5 = <" + new java.text.DecimalFormat("#0.0000").format(FN5[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN5[1]) + ">");
        
        
        double[] t1x6 = {1.0, 0.0};
        double[] t2x6 = {0.5906, 0.4094};
        double[] t3x6 = {0.3009, 0.6991};
        double[] FN61 = {0.0, 0.0};
        double[] FN62 = {0.0, 0.0};
        double[] FN63 = {0.0, 0.0};
        double[] FN6 = {0.0, 0.0};
        FN61 = FNmFN(1.0, t1x6, RNmFN(1.0, www[4], MMM[6][4]));       
        FN62 = FNmFN(1.0, t2x6, FNpFN(1.0, RNmFN(1.0, www[2], MMM[6][2]), RNmFN(1.0, www[3], MMM[6][3])));
        FN63 = FNmFN(1.0, t3x6, FNpFN(1.0, RNmFN(1.0, www[1], MMM[6][1]), RNmFN(1.0, www[5], MMM[6][5])));
        FN6 = FNpFN(1.0, FNpFN(1.0, FN61, FN62), FN63);
        System.out.println("FN6 = <" + new java.text.DecimalFormat("#0.0000").format(FN6[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN6[1]) + ">");
        
        
        double[] t1x7 = {1.0, 0.0};
        double[] t2x7 = {0.6722, 0.3278};
        double[] t3x7 = {0.3748, 0.6252};
        double[] FN71 = {0.0, 0.0};
        double[] FN72 = {0.0, 0.0};
        double[] FN73 = {0.0, 0.0};
        double[] FN7 = {0.0, 0.0};
        FN71 = FNmFN(1.0, t1x7, RNmFN(1.0, www[4], MMM[7][4]));       
        FN72 = FNmFN(1.0, t2x7, FNpFN(1.0, RNmFN(1.0, www[2], MMM[7][2]), RNmFN(1.0, www[3], MMM[7][3])));
        FN73 = FNmFN(1.0, t3x7, FNpFN(1.0, RNmFN(1.0, www[1], MMM[7][1]), RNmFN(1.0, www[5], MMM[7][5])));
        FN7 = FNpFN(1.0, FNpFN(1.0, FN71, FN72), FN73);
        System.out.println("FN7 = <" + new java.text.DecimalFormat("#0.0000").format(FN7[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN7[1]) + ">");
        
        File fileWrite21 = new File("E2FWPA1.txt");
        BufferedWriter writer21 = new BufferedWriter(new FileWriter(fileWrite21, true)); 
        File fileWrite22 = new File("E2FWPA2.txt");
        BufferedWriter writer22 = new BufferedWriter(new FileWriter(fileWrite22, true));
        File fileWrite23 = new File("E2FWPA3.txt");
        BufferedWriter writer23 = new BufferedWriter(new FileWriter(fileWrite23, true));
        File fileWrite24 = new File("E2FWPA4.txt");
        BufferedWriter writer24 = new BufferedWriter(new FileWriter(fileWrite24, true)); 
        File fileWrite25 = new File("E2FWPA5.txt");
        BufferedWriter writer25 = new BufferedWriter(new FileWriter(fileWrite25, true));  
        File fileWrite26 = new File("E2FWPA6.txt");
        BufferedWriter writer26 = new BufferedWriter(new FileWriter(fileWrite26, true));  
        File fileWrite27 = new File("E2FWPA7.txt");
        BufferedWriter writer27 = new BufferedWriter(new FileWriter(fileWrite27, true));  
        
        writer21.write(String.valueOf(FN1[0]) + "\r\n");
        writer22.write(String.valueOf(FN2[0]) + "\r\n");
        writer23.write(String.valueOf(FN3[0]) + "\r\n");
        writer24.write(String.valueOf(FN4[0]) + "\r\n");
        writer25.write(String.valueOf(FN5[0]) + "\r\n");
        writer26.write(String.valueOf(FN6[0]) + "\r\n");
        writer27.write(String.valueOf(FN7[0]) + "\r\n");
        writer21.close();
        writer22.close();
        writer23.close();
        writer24.close();
        writer25.close();
        writer26.close();
        writer27.close();*/
        
        //Experiment 3
        double[] column1 = {18.34, 21.31, 21.31, 20.02, 20.97, 21.90};        
        double[] column2 = {2.88, 3.09, 3.09, 5.11, 4.63, 4.82};                            
        double[] column3 = {105.33, 143.08, 143.08, 271.47, 231.40, 250.10};    
        double[] column4 = {1588.82, 2119.19, 3646.78, 1889.14, 1474.98, 745.22};
        double[] column5 = {2.72, 1.65, 1.65, 1.65, 1.00, 1.00};
                       
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length];
        
        ratio1 = obod.RatioOfNumericalValue(column1);
        ratio2 = obod.RatioOfNumericalValue(column2);
        ratio3 = obod.RatioOfNumericalValue(column3);
        ratio4 = obod.RatioOfNumericalValue(column4);
        ratio5 = obod.RatioOfNumericalValue(column5);
                 
        double[][][] MM = {
            //{{1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//0
            //{{1-ratio1[0], ratio1[0]}, {0.7093, 0.2907}, {0.7858, 0.2142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//0
            //{{1-ratio1[0], ratio1[0]}, {0.6093, 0.3907}, {0.6858, 0.3142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//1
            //{{1-ratio1[0], ratio1[0]}, {0.5093, 0.4907}, {0.5858, 0.4142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//2
            //{{1-ratio1[0], ratio1[0]}, {0.4093, 0.5907}, {0.4858, 0.5142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//3
            //{{1-ratio1[0], ratio1[0]}, {0.3093, 0.6907}, {0.3858, 0.6142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//4
            //{{1-ratio1[0], ratio1[0]}, {0.2093, 0.7907}, {0.2858, 0.7142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//5
            //{{1-ratio1[0], ratio1[0]}, {0.1093, 0.8907}, {0.1858, 0.8142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//6
            {{1-ratio1[0], ratio1[0]}, {0.0093, 0.9907}, {0.0858, 0.9142}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},//7
            
            {{1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}, {ratio5[3], 1-ratio5[3]}},
            {{1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}, {ratio5[4], 1-ratio5[4]}},
            {{1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}, {ratio5[5], 1-ratio5[5]}}
        };
        double[][][] MM1 = {
            {{1-ratio1[0], ratio1[0]}, {ratio5[0], 1-ratio5[0]}},
            {{1-ratio1[1], ratio1[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1-ratio1[2], ratio1[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1-ratio1[3], ratio1[3]}, {ratio5[3], 1-ratio5[3]}},
            {{1-ratio1[4], ratio1[4]}, {ratio5[4], 1-ratio5[4]}},
            {{1-ratio1[5], ratio1[5]}, {ratio5[5], 1-ratio5[5]}}
        };
        double[][][] MM2 = {
            //{{1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}},//0            
            //{{0.7093, 0.2907}, {0.7858, 0.2142}, {1-ratio4[0], ratio4[0]}},//0
            //{{0.6093, 0.3907}, {0.6858, 0.3142}, {1-ratio4[0], ratio4[0]}},//1
            //{{0.5093, 0.4907}, {0.5858, 0.4142}, {1-ratio4[0], ratio4[0]}},//2
            //{{0.4093, 0.5907}, {0.4858, 0.5142}, {1-ratio4[0], ratio4[0]}},//3
            //{{0.3093, 0.6907}, {0.3858, 0.6142}, {1-ratio4[0], ratio4[0]}},//4
            //{{0.2093, 0.7907}, {0.2858, 0.7142}, {1-ratio4[0], ratio4[0]}},//5
            //{{0.1093, 0.8907}, {0.1858, 0.8142}, {1-ratio4[0], ratio4[0]}},//6
            {{0.0093, 0.9907}, {0.0858, 0.9142}, {1-ratio4[0], ratio4[0]}},//7
            
            {{1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}},
            {{1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}},
            {{1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}},
            {{1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}},
            {{1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}}
        };
        
        int m = 6;
        int n = 5;
        double q = 1.0;       
        double[] w = {0.2, 0.2, 0.2, 0.2, 0.2};
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP4554 = new double[m];
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][1][0], MM[i][1][1]);
            SUPP1331[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][2][0], MM[i][2][1]);
            SUPP1441[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][3][0], MM[i][3][1]);
            SUPP1551[i] = 1 - distanceValue(q, MM[i][0][0], MM[i][0][1], MM[i][4][0], MM[i][4][1]);
            SUPP2332[i] = 1 - distanceValue(q, MM[i][1][0], MM[i][1][1], MM[i][2][0], MM[i][2][1]);
            SUPP2442[i] = 1 - distanceValue(q, MM[i][1][0], MM[i][1][1], MM[i][3][0], MM[i][3][1]);
            SUPP2552[i] = 1 - distanceValue(q, MM[i][1][0], MM[i][1][1], MM[i][4][0], MM[i][4][1]);
            SUPP3443[i] = 1 - distanceValue(q, MM[i][2][0], MM[i][2][1], MM[i][3][0], MM[i][3][1]);
            SUPP3553[i] = 1 - distanceValue(q, MM[i][2][0], MM[i][2][1], MM[i][4][0], MM[i][4][1]);
            SUPP4554[i] = 1 - distanceValue(q, MM[i][3][0], MM[i][3][1], MM[i][4][0], MM[i][4][1]);
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(SUPP4554[i]));         
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i];
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(TT5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");           
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
              
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        for (int i = 0; i < m; i++) {     
            w1[i] = (w[0]*(1.0 + TT1[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w2[i] = (w[1]*(1.0 + TT2[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w3[i] = (w[2]*(1.0 + TT3[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w4[i] = (w[3]*(1.0 + TT4[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            w5[i] = (w[4]*(1.0 + TT5[i])) / (w[0]*(1.0 + TT1[i]) + w[1]*(1.0 + TT2[i]) + w[2]*(1.0 + TT3[i]) + w[3]*(1.0 + TT4[i]) + w[4]*(1.0 + TT5[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));           
        }
        //System.out.println("@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
        
        double[][] www1 = {
            {w1[0],  w5[0]},
            {w1[1],  w5[1]},
            {w1[2],  w5[2]},
            {w1[3],  w5[3]},
            {w1[4],  w5[4]},
            {w1[5],  w5[5]}
        };
        double[][] www2 = {
            {w2[0], w3[0], w4[0]},
            {w2[1], w3[1], w4[1]},
            {w2[2], w3[2], w4[2]},
            {w2[3], w3[3], w4[3]},
            {w2[4], w3[4], w4[4]},
            {w2[5], w3[5], w4[5]}
        };
        
        double[][] rr1 = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rr1[k][r] = 0.0;
            }           
        }
        double[][] rr2 = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rr2[k][r] = 0.0;
            }           
        }     
        double[][] rrr = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rrr[k][r] = 0.0;
            }           
        }
                        
        double[] delta1 = {1.0, 2.0};
        double[] delta2 = {1.0, 2.0, 3.0};
      
        rr1 = obod.qROFWMM(m, 2, q, MM1, www1, delta1);
        rr2 = obod.qROFWMM(m, 3, q, MM2, www2, delta2);
        double[][][] MMMM = {
            {{rr1[0][0], rr1[0][1]}, {rr2[0][0], rr2[0][1]}},
            {{rr1[1][0], rr1[1][1]}, {rr2[1][0], rr2[1][1]}},
            {{rr1[2][0], rr1[2][1]}, {rr2[2][0], rr2[2][1]}},
            {{rr1[3][0], rr1[3][1]}, {rr2[3][0], rr2[3][1]}},
            {{rr1[4][0], rr1[4][1]}, {rr2[4][0], rr2[4][1]}},
            {{rr1[5][0], rr1[5][1]}, {rr2[5][0], rr2[5][1]}}
        };
        
        rrr = obod.qROFPAA(m, 2, q, MMMM);
                                               
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rrr[k][1]));
        }
        /*
        File fileWrite21 = new File("FWPPMM1.txt");
        BufferedWriter writer21 = new BufferedWriter(new FileWriter(fileWrite21, true)); 
        File fileWrite22 = new File("FWPPMM2.txt");
        BufferedWriter writer22 = new BufferedWriter(new FileWriter(fileWrite22, true));
        File fileWrite23 = new File("FWPPMM3.txt");
        BufferedWriter writer23 = new BufferedWriter(new FileWriter(fileWrite23, true));
        File fileWrite24 = new File("FWPPMM4.txt");
        BufferedWriter writer24 = new BufferedWriter(new FileWriter(fileWrite24, true)); 
        File fileWrite25 = new File("FWPPMM5.txt");
        BufferedWriter writer25 = new BufferedWriter(new FileWriter(fileWrite25, true));  
        File fileWrite26 = new File("FWPPMM6.txt");
        BufferedWriter writer26 = new BufferedWriter(new FileWriter(fileWrite26, true));  
        
        writer21.write(String.valueOf(rrr[0][0]) + "\r\n");
        writer22.write(String.valueOf(rrr[1][0]) + "\r\n");
        writer23.write(String.valueOf(rrr[2][0]) + "\r\n");
        writer24.write(String.valueOf(rrr[3][0]) + "\r\n");
        writer25.write(String.valueOf(rrr[4][0]) + "\r\n");
        writer26.write(String.valueOf(rrr[5][0]) + "\r\n");
        writer21.close();
        writer22.close();
        writer23.close();
        writer24.close();
        writer25.close();
        writer26.close();*/
        
        
        double[][] rOfSWA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                rOfSWA[k][r] = 0.0;
            }           
        }
        
        rOfSWA = obod.qROFSWA(m, n, MM, w);
        for (int k = 0; k < m; k++) { 
            int index = k + 1;
            System.out.println("qROFN[" + index + "] = ");
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rOfSWA[k][0]));
            System.out.println(new java.text.DecimalFormat("#0.0000").format(rOfSWA[k][1]));
        }
        
        File fileWrite11 = new File("SWA1.txt");
        BufferedWriter writer11 = new BufferedWriter(new FileWriter(fileWrite11, true)); 
        File fileWrite12 = new File("SWA2.txt");
        BufferedWriter writer12 = new BufferedWriter(new FileWriter(fileWrite12, true));
        File fileWrite13 = new File("SWA3.txt");
        BufferedWriter writer13 = new BufferedWriter(new FileWriter(fileWrite13, true));
        File fileWrite14 = new File("SWA4.txt");
        BufferedWriter writer14 = new BufferedWriter(new FileWriter(fileWrite14, true)); 
        File fileWrite15 = new File("SWA5.txt");
        BufferedWriter writer15 = new BufferedWriter(new FileWriter(fileWrite15, true));  
        File fileWrite16 = new File("SWA6.txt");
        BufferedWriter writer16 = new BufferedWriter(new FileWriter(fileWrite16, true));
        
        writer11.write(String.valueOf(rOfSWA[0][0]) + "\r\n");
        writer12.write(String.valueOf(rOfSWA[1][0]) + "\r\n");
        writer13.write(String.valueOf(rOfSWA[2][0]) + "\r\n");
        writer14.write(String.valueOf(rOfSWA[3][0]) + "\r\n");
        writer15.write(String.valueOf(rOfSWA[4][0]) + "\r\n");
        writer16.write(String.valueOf(rOfSWA[5][0]) + "\r\n");      
        writer11.close();
        writer12.close();
        writer13.close();
        writer14.close();
        writer15.close();
        writer16.close();       
        
        /*
        //Experiment 4
        double[] column1 = {5.40, 3.56, 5.76, 3.85, 8.32, 5.29, 8.35};        
        double[] column2 = {4.32, 4.27, 4.32, 4.27, 6.83, 7.56, 6.79};                            
        double[] column3 = {57.0, 56.0, 57.0, 56.0, 84.0, 92.0, 83.0};    
        double[] column4 = {510.0, 650.0, 712.0, 702.0, 395.0, 652.0, 522.0};
        double[] column5 = {1.65, 2.72, 1.65, 2.72, 0.85, 1.95, 0.85};
                
        double[] ratio1 = new double[column1.length];
        double[] ratio2 = new double[column2.length];
        double[] ratio3 = new double[column3.length];
        double[] ratio4 = new double[column4.length];
        double[] ratio5 = new double[column5.length];
        
        ratio1 = obod.RatioOfNumericalValue(column1);
        ratio2 = obod.RatioOfNumericalValue(column2);
        ratio3 = obod.RatioOfNumericalValue(column3);
        ratio4 = obod.RatioOfNumericalValue(column4);
        ratio5 = obod.RatioOfNumericalValue(column5);            
        
        double[][][] MMM = {
            {{1.0000, 0.0000}, {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000},         {1.0000, 0.0000}},
            {{1.0000, 0.0000}, {1-ratio1[0], ratio1[0]}, {1-ratio2[0], ratio2[0]}, {1-ratio3[0], ratio3[0]}, {1-ratio4[0], ratio4[0]}, {ratio5[0], 1-ratio5[0]}},
            {{1.0000, 0.0000}, {1-ratio1[1], ratio1[1]}, {1-ratio2[1], ratio2[1]}, {1-ratio3[1], ratio3[1]}, {1-ratio4[1], ratio4[1]}, {ratio5[1], 1-ratio5[1]}},
            {{1.0000, 0.0000}, {1-ratio1[2], ratio1[2]}, {1-ratio2[2], ratio2[2]}, {1-ratio3[2], ratio3[2]}, {1-ratio4[2], ratio4[2]}, {ratio5[2], 1-ratio5[2]}},
            {{1.0000, 0.0000}, {1-ratio1[3], ratio1[3]}, {1-ratio2[3], ratio2[3]}, {1-ratio3[3], ratio3[3]}, {1-ratio4[3], ratio4[3]}, {ratio5[3], 1-ratio5[3]}},
            
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {1-ratio4[4], ratio4[4]}, {ratio5[4], 1-ratio5[4]}},//0
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.7520, 0.2480}, {ratio5[4], 1-ratio5[4]}},//0
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.7220, 0.2780}, {ratio5[4], 1-ratio5[4]}},//1
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6920, 0.3080}, {ratio5[4], 1-ratio5[4]}},//2
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6620, 0.3380}, {ratio5[4], 1-ratio5[4]}},//3
           // {{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6320, 0.3680}, {ratio5[4], 1-ratio5[4]}},//4
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.6020, 0.3980}, {ratio5[4], 1-ratio5[4]}},//5
            //{{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.5720, 0.4280}, {ratio5[4], 1-ratio5[4]}},//6
            {{1.0000, 0.0000}, {1-ratio1[4], ratio1[4]}, {1-ratio2[4], ratio2[4]}, {1-ratio3[4], ratio3[4]}, {0.5420, 0.4580}, {ratio5[4], 1-ratio5[4]}},//7
            
            {{1.0000, 0.0000}, {1-ratio1[5], ratio1[5]}, {1-ratio2[5], ratio2[5]}, {1-ratio3[5], ratio3[5]}, {1-ratio4[5], ratio4[5]}, {ratio5[5], 1-ratio5[5]}},
            {{1.0000, 0.0000}, {1-ratio1[6], ratio1[6]}, {1-ratio2[6], ratio2[6]}, {1-ratio3[6], ratio3[6]}, {1-ratio4[6], ratio4[6]}, {ratio5[6], 1-ratio5[6]}}
        };         
             
        int m = 8;
        int n = 6;
        double q = 1.0;
        double[] w = {0.0000, 0.125, 0.125, 0.125, 0.5000, 0.125};
        double[] SUPP1221 = new double[m];
        double[] SUPP1331 = new double[m];
        double[] SUPP1441 = new double[m];
        double[] SUPP1551 = new double[m];
        double[] SUPP2332 = new double[m];
        double[] SUPP2442 = new double[m];
        double[] SUPP2552 = new double[m];
        double[] SUPP3443 = new double[m];
        double[] SUPP3553 = new double[m];
        double[] SUPP4554 = new double[m];
        for (int i = 1; i < m; i++) {          
            SUPP1221[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][2][0], MMM[i][2][1]);
            SUPP1331[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][3][0], MMM[i][3][1]);
            SUPP1441[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][4][0], MMM[i][4][1]);
            SUPP1551[i] = 1 - distanceValue(q, MMM[i][1][0], MMM[i][1][1], MMM[i][5][0], MMM[i][5][1]);
            SUPP2332[i] = 1 - distanceValue(q, MMM[i][2][0], MMM[i][2][1], MMM[i][3][0], MMM[i][3][1]);
            SUPP2442[i] = 1 - distanceValue(q, MMM[i][2][0], MMM[i][2][1], MMM[i][4][0], MMM[i][4][1]);
            SUPP2552[i] = 1 - distanceValue(q, MMM[i][2][0], MMM[i][2][1], MMM[i][5][0], MMM[i][5][1]);
            SUPP3443[i] = 1 - distanceValue(q, MMM[i][3][0], MMM[i][3][1], MMM[i][4][0], MMM[i][4][1]);
            SUPP3553[i] = 1 - distanceValue(q, MMM[i][3][0], MMM[i][3][1], MMM[i][5][0], MMM[i][5][1]);
            SUPP4554[i] = 1 - distanceValue(q, MMM[i][4][0], MMM[i][4][1], MMM[i][5][0], MMM[i][5][1]);
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(SUPP3443[i]));         
        }
        
        double[] TT1 = new double[m];
        double[] TT2 = new double[m]; 
        double[] TT3 = new double[m]; 
        double[] TT4 = new double[m];
        double[] TT5 = new double[m];
        for (int i = 1; i < m; i++) {          
            TT1[i] = SUPP1221[i] + SUPP1331[i] + SUPP1441[i] + SUPP1551[i]; 
            TT2[i] = SUPP1221[i] + SUPP2332[i] + SUPP2442[i] + SUPP2552[i];
            TT3[i] = SUPP1331[i] + SUPP2332[i] + SUPP3443[i] + SUPP3553[i];
            TT4[i] = SUPP1441[i] + SUPP2442[i] + SUPP3443[i] + SUPP4554[i];
            TT5[i] = SUPP1551[i] + SUPP2552[i] + SUPP3553[i] + SUPP4554[i];
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(TT4[i]));           
        }
                   
        double[] w1 = new double[m];
        double[] w2 = new double[m];
        double[] w3 = new double[m];
        double[] w4 = new double[m];
        double[] w5 = new double[m];
               
        for (int i = 1; i < m; i++) {     
            w1[i] = (w[1]*(1.0 + TT1[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w2[i] = (w[2]*(1.0 + TT2[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w3[i] = (w[3]*(1.0 + TT3[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w4[i] = (w[4]*(1.0 + TT4[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            w5[i] = (w[5]*(1.0 + TT5[i])) / (w[1]*(1.0 + TT1[i]) + w[2]*(1.0 + TT2[i]) + w[3]*(1.0 + TT3[i]) + w[4]*(1.0 + TT4[i]) + w[5]*(1.0 + TT5[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w1[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w2[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w3[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w4[i]));
            //System.out.println(new java.text.DecimalFormat("#0.0000").format(w5[i]));
        }
        
        double[][] www = {
            {1.000, 1.000, 1.000, 1.000, 1.000, 1.000},
            {1.000, w1[1], w2[1], w3[1], w4[1], w5[1]},
            {1.000, w1[2], w2[2], w3[2], w4[2], w5[2]},
            {1.000, w1[3], w2[3], w3[3], w4[3], w5[3]},
            {1.000, w1[4], w2[4], w3[4], w4[4], w5[4]},
            {1.000, w1[5], w2[5], w3[5], w4[5], w5[5]},
            {1.000, w1[6], w2[6], w3[6], w4[6], w5[6]},
            {1.000, w1[7], w2[7], w3[7], w4[7], w5[7]}
        };
        
        double[] t1x1 = {1.0, 0.0};
        double[] t2x1 = {0.6797, 0.3203};
        double[] t3x1 = {0.4834, 0.5166};
        double[] FN11 = {0.0, 0.0};
        double[] FN12 = {0.0, 0.0};
        double[] FN13 = {0.0, 0.0};
        double[] FN1 = {0.0, 0.0};
        FN11 = FNmFN(1.0, t1x1, RNmFN(1.0, www[1][4], MMM[1][4]));       
        FN12 = FNmFN(1.0, t2x1, FNpFN(1.0, RNmFN(1.0, www[1][2], MMM[1][2]), RNmFN(1.0, www[1][3], MMM[1][3])));
        FN13 = FNmFN(1.0, t3x1, FNpFN(1.0, RNmFN(1.0, www[1][1], MMM[1][1]), RNmFN(1.0, www[1][5], MMM[1][5])));
        FN1 = FNpFN(1.0, FNpFN(1.0, FN11, FN12), FN13);
        System.out.println("FN1 = <" + new java.text.DecimalFormat("#0.0000").format(FN1[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN1[1]) + ">");
        //System.out.println("S1 = " + new java.text.DecimalFormat("#0.0000").format(FN1[0]-FN1[1]));
        
        double[] t1x2 = {1.0, 0.0};
        double[] t2x2 = {0.5918, 0.4082};
        double[] t3x2 = {0.2416, 0.7584};
        double[] FN21 = {0.0, 0.0};
        double[] FN22 = {0.0, 0.0};
        double[] FN23 = {0.0, 0.0};
        double[] FN2 = {0.0, 0.0};
        FN21 = FNmFN(1.0, t1x2, RNmFN(1.0, www[2][4], MMM[2][4]));       
        FN22 = FNmFN(1.0, t2x2, FNpFN(1.0, RNmFN(1.0, www[2][2], MMM[2][2]), RNmFN(1.0, www[2][3], MMM[2][3])));
        FN23 = FNmFN(1.0, t3x2, FNpFN(1.0, RNmFN(1.0, www[2][1], MMM[2][1]), RNmFN(1.0, www[2][5], MMM[2][5])));
        FN2 = FNpFN(1.0, FNpFN(1.0, FN21, FN22), FN23);
        System.out.println("FN2 = <" + new java.text.DecimalFormat("#0.0000").format(FN2[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN2[1]) + ">");
        //System.out.println("S2 = " + new java.text.DecimalFormat("#0.0000").format(FN2[0]-FN2[1]));
        
        double[] t1x3 = {1.0, 0.0};
        double[] t2x3 = {0.5529, 0.4471};
        double[] t3x3 = {0.3932, 0.6068};
        double[] FN31 = {0.0, 0.0};
        double[] FN32 = {0.0, 0.0};
        double[] FN33 = {0.0, 0.0};
        double[] FN3 = {0.0, 0.0};
        FN31 = FNmFN(1.0, t1x3, RNmFN(1.0, www[3][4], MMM[3][4]));       
        FN32 = FNmFN(1.0, t2x3, FNpFN(1.0, RNmFN(1.0, www[3][2], MMM[3][2]), RNmFN(1.0, www[3][3], MMM[3][3])));
        FN33 = FNmFN(1.0, t3x3, FNpFN(1.0, RNmFN(1.0, www[3][1], MMM[3][1]), RNmFN(1.0, www[3][5], MMM[3][5])));
        FN3 = FNpFN(1.0, FNpFN(1.0, FN31, FN32), FN33);
        System.out.println("FN3 = <" + new java.text.DecimalFormat("#0.0000").format(FN3[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN3[1]) + ">");
        //System.out.println("S3 = " + new java.text.DecimalFormat("#0.0000").format(FN3[0]-FN3[1]));
        
        double[] t1x4 = {1.0, 0.0};
        double[] t2x4 = {0.5592, 0.4408};
        double[] t3x4 = {0.3995, 0.6005};
        double[] FN41 = {0.0, 0.0};
        double[] FN42 = {0.0, 0.0};
        double[] FN43 = {0.0, 0.0};
        double[] FN4 = {0.0, 0.0};
        FN41 = FNmFN(1.0, t1x4, RNmFN(1.0, www[4][4], MMM[4][4]));       
        FN42 = FNmFN(1.0, t2x4, FNpFN(1.0, RNmFN(1.0, www[4][2], MMM[4][2]), RNmFN(1.0, www[4][3], MMM[4][3])));
        FN43 = FNmFN(1.0, t3x4, FNpFN(1.0, RNmFN(1.0, www[4][1], MMM[4][1]), RNmFN(1.0, www[4][5], MMM[4][5])));
        FN4 = FNpFN(1.0, FNpFN(1.0, FN41, FN42), FN43);
        System.out.println("FN4 = <" + new java.text.DecimalFormat("#0.0000").format(FN4[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN4[1]) + ">");
        //System.out.println("S4 = " + new java.text.DecimalFormat("#0.0000").format(FN4[0]-FN4[1]));
        
        double[] t1x5 = {1.0, 0.0};
        double[] t2x5 = {0.7520, 0.2480};
        double[] t3x5 = {0.4152, 0.5848};
        double[] FN51 = {0.0, 0.0};
        double[] FN52 = {0.0, 0.0};
        double[] FN53 = {0.0, 0.0};
        double[] FN5 = {0.0, 0.0};
        FN51 = FNmFN(1.0, t1x5, RNmFN(1.0, www[5][4], MMM[5][4]));       
        FN52 = FNmFN(1.0, t2x5, FNpFN(1.0, RNmFN(1.0, www[5][2], MMM[5][2]), RNmFN(1.0, www[5][3], MMM[5][3])));
        FN53 = FNmFN(1.0, t3x5, FNpFN(1.0, RNmFN(1.0, www[5][1], MMM[5][1]), RNmFN(1.0, www[5][5], MMM[5][5])));
        FN5 = FNpFN(1.0, FNpFN(1.0, FN51, FN52), FN53);
        System.out.println("FN5 = <" + new java.text.DecimalFormat("#0.0000").format(FN5[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN5[1]) + ">");
        //System.out.println("S5 = " + new java.text.DecimalFormat("#0.0000").format(FN5[0]-FN5[1]));
        
        double[] t1x6 = {1.0, 0.0};
        double[] t2x6 = {0.5906, 0.4094};
        double[] t3x6 = {0.3009, 0.6991};
        double[] FN61 = {0.0, 0.0};
        double[] FN62 = {0.0, 0.0};
        double[] FN63 = {0.0, 0.0};
        double[] FN6 = {0.0, 0.0};
        FN61 = FNmFN(1.0, t1x6, RNmFN(1.0, www[6][4], MMM[6][4]));       
        FN62 = FNmFN(1.0, t2x6, FNpFN(1.0, RNmFN(1.0, www[6][2], MMM[6][2]), RNmFN(1.0, www[6][3], MMM[6][3])));
        FN63 = FNmFN(1.0, t3x6, FNpFN(1.0, RNmFN(1.0, www[6][1], MMM[6][1]), RNmFN(1.0, www[6][5], MMM[6][5])));
        FN6 = FNpFN(1.0, FNpFN(1.0, FN61, FN62), FN63);
        System.out.println("FN6 = <" + new java.text.DecimalFormat("#0.0000").format(FN6[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN6[1]) + ">");
        //System.out.println("S6 = " + new java.text.DecimalFormat("#0.0000").format(FN6[0]-FN6[1]));
        
        double[] t1x7 = {1.0, 0.0};
        double[] t2x7 = {0.6722, 0.3278};
        double[] t3x7 = {0.3748, 0.6252};
        double[] FN71 = {0.0, 0.0};
        double[] FN72 = {0.0, 0.0};
        double[] FN73 = {0.0, 0.0};
        double[] FN7 = {0.0, 0.0};
        FN71 = FNmFN(1.0, t1x7, RNmFN(1.0, www[7][4], MMM[7][4]));       
        FN72 = FNmFN(1.0, t2x7, FNpFN(1.0, RNmFN(1.0, www[7][2], MMM[7][2]), RNmFN(1.0, www[7][3], MMM[7][3])));
        FN73 = FNmFN(1.0, t3x7, FNpFN(1.0, RNmFN(1.0, www[7][1], MMM[7][1]), RNmFN(1.0, www[7][5], MMM[7][5])));
        FN7 = FNpFN(1.0, FNpFN(1.0, FN71, FN72), FN73);
        System.out.println("FN7 = <" + new java.text.DecimalFormat("#0.0000").format(FN7[0]) + ", " + 
                                       new java.text.DecimalFormat("#0.0000").format(FN7[1]) + ">");
        //System.out.println("S7 = " + new java.text.DecimalFormat("#0.0000").format(FN7[0]-FN7[1]));
        File fileWrite21 = new File("E4FWPPA1.txt");
        BufferedWriter writer21 = new BufferedWriter(new FileWriter(fileWrite21, true)); 
        File fileWrite22 = new File("E4FWPPA2.txt");
        BufferedWriter writer22 = new BufferedWriter(new FileWriter(fileWrite22, true));
        File fileWrite23 = new File("E4FWPPA3.txt");
        BufferedWriter writer23 = new BufferedWriter(new FileWriter(fileWrite23, true));
        File fileWrite24 = new File("E4FWPPA4.txt");
        BufferedWriter writer24 = new BufferedWriter(new FileWriter(fileWrite24, true)); 
        File fileWrite25 = new File("E4FWPPA5.txt");
        BufferedWriter writer25 = new BufferedWriter(new FileWriter(fileWrite25, true));  
        File fileWrite26 = new File("E4FWPPA6.txt");
        BufferedWriter writer26 = new BufferedWriter(new FileWriter(fileWrite26, true));  
        File fileWrite27 = new File("E4FWPPA7.txt");
        BufferedWriter writer27 = new BufferedWriter(new FileWriter(fileWrite27, true));  
        
        writer21.write(String.valueOf(FN1[0]) + "\r\n");
        writer22.write(String.valueOf(FN2[0]) + "\r\n");
        writer23.write(String.valueOf(FN3[0]) + "\r\n");
        writer24.write(String.valueOf(FN4[0]) + "\r\n");
        writer25.write(String.valueOf(FN5[0]) + "\r\n");
        writer26.write(String.valueOf(FN6[0]) + "\r\n");
        writer27.write(String.valueOf(FN7[0]) + "\r\n");
        writer21.close();
        writer22.close();
        writer23.close();
        writer24.close();
        writer25.close();
        writer26.close();
        writer27.close(); */         
    }
    
    public static void permutation(ArrayList<Integer> s, ArrayList<Integer> rs, ArrayList<ArrayList<Integer>> res) {                     
        if(s.size()== 1) {               
            rs.add(s.get(0));  
            ArrayList<Integer> tmp=new ArrayList<Integer>();  
            for(Integer a:rs)  
                tmp.add(a);
            res.add(tmp);
            rs.remove(rs.size()-1);                              
        } else {                 
            for(int i=0;i<s.size();i++) {                    
                rs.add(s.get(i));   
                ArrayList<Integer> tmp=new ArrayList<Integer>();  
                for(Integer a:s)  
                     tmp.add(a);  
                tmp.remove(i);  
                permutation(tmp,rs,res);  
                rs.remove(rs.size()-1);                
            }  
        }                     
    }  
     
    public static double factorial1(int number) {
        double result = 1;
        for (int factor = 2; factor <= number; factor++) {
            result *= factor;
        }
        return 1.0/result;
    }

    public double[][] qROFWMM(int m, int n, double q, double[][][] theta, double[][] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q), n*w[k][curidx]), delta[j]);
                    product1 *= Math.pow((1.0 - Math.pow(theta[k][curidx][1], q*n*w[k][curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);                                   
        }        
        return result;       
    }
    
    public double[][] qROFWMM1(int m, int n, double q, double[][][] theta, double[] w, double[] delta) {
        ArrayList<Integer> s2 = new ArrayList<Integer>();  
        ArrayList<Integer> rs = new ArrayList<Integer>();  
        ArrayList<ArrayList<Integer>> qp = new ArrayList<ArrayList<Integer>>();  
        for(int i = 0;i < n; i++)  
            s2.add(i);  
        permutation(s2, rs, qp);                     
        double[][] result = new double[m][2];             
        for (int k = 0; k < m; k++) {           
            result[k][0] = 1.0;
            result[k][1] = 1.0;                      
            for(int i = 0; i < qp.size(); i++) {
                double product0 = 1.0;
                double product1 = 1.0;
                ArrayList<Integer> curQpl = qp.get(i);
                for(int j = 0; j < n; j++) {
                    int curidx = curQpl.get(j);
                    product0 *= Math.pow(1.0 - Math.pow(1.0 - Math.pow(theta[k][curidx][0], q), n*w[curidx]), delta[j]);
                    product1 *= Math.pow((1.0 - Math.pow(theta[k][curidx][1], q*n*w[curidx])), delta[j]);
                }                              
                result[k][0] *= (1.0 - product0);
                result[k][1] *= (1.0 - product1);
            }           
            double sumdelta1 = 1.0 / DoubleStream.of(delta).sum();            
            result[k][0] = Math.pow(1.0 - Math.pow(result[k][0], factorial1(n)), sumdelta1/q);
            result[k][1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(result[k][1], factorial1(n)), sumdelta1), 1.0/q);                                   
        }        
        return result;       
    } 
    
    // Aggregate q-ROFNs using the Partitioned Arithmetic Averaging (PAA) operator
    public double[][] qROFPAA(int m, int N, double q, double[][][] theta) {
        double[][] resultOfqROFPAA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFPAA[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < N; i++) {                                  
                product[k][0] = product[k][0] * (1 - Math.pow(theta[k][i][0], q));
                product[k][1] = product[k][1] * Math.pow(theta[k][i][1], q);                                                         
            }
            resultOfqROFPAA[k][0] = Math.pow(1 - Math.pow(product[k][0], 1.0/N), 1.0/q);
            resultOfqROFPAA[k][1] = Math.pow(product[k][1], 1.0/(q*N));
        }
        return resultOfqROFPAA;
    }
    
    public double[][] qROFWA(int m, int n, double q, double[][][] theta, double[] w) {
        double[][] resultOfqROFWA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFWA[k][r] = 0.0;
            }           
        }   
        double[][] product = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                product[k][r] = 1.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                
                product[k][0] = product[k][0] * Math.pow(1 - Math.pow(theta[k][i][0], q), w[i]);
                product[k][1] = product[k][1] * Math.pow(theta[k][i][1], w[i]);                        
                    
            }
            resultOfqROFWA[k][0] = Math.pow(1 - product[k][0], 1.0/q);
            resultOfqROFWA[k][1] = product[k][1];
        }
        return resultOfqROFWA;
    }
    
    public double[][] qROFSWA(int m, int n, double[][][] theta, double[] w) {
        double[][] resultOfqROFSWA = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                resultOfqROFSWA[k][r] = 0.0;
            }           
        }   
        double[][] sum = new double[m][2];
        for (int k = 0; k < m; k++) {
            for (int r = 0; r < 2; r++) {
                sum[k][r] = 0.0;
            }           
        }      
        for (int k = 0; k < m; k++) {
            for (int i = 0; i < n; i++) {                
                sum[k][0] = sum[k][0] + w[i]*theta[k][i][0];                       
                sum[k][1] = sum[k][1] + w[i]*theta[k][i][1];                        
                    
            }
            resultOfqROFSWA[k][0] = sum[k][0];
            resultOfqROFSWA[k][1] = sum[k][1];
        }
        return resultOfqROFSWA;
    }
    
    // Define a function to compute the score value of a q-ROFN
    public double[] getScoreValue(int m, double q, double[][] theta) {
        double[] scoreValue = new double[m];
        for (int k = 0; k < m; k++) {
            scoreValue[k] = Math.pow(theta[k][0], q) - Math.pow(theta[k][1], q);
        }
        return scoreValue;
    }
    
    // Define a function to compute the accuracy value of a q-ROFN
    public double[] getAccuracyValue(int m, double q, double[][] theta) {
        double[] accuracyValue = new double[m];
        for (int k = 0; k < m; k++) {
            accuracyValue[k] = Math.pow(theta[k][0], q) + Math.pow(theta[k][1], q);
        }
        return accuracyValue;
    }
    
    //Define a function to quantify numerical values
    public double[] RatioOfNumericalValue(double[] column) {
        double[] ratio = new double[column.length];
        double quadraticSum = 0.0;
        for (int i = 0; i < column.length; i++) {
            quadraticSum = quadraticSum + column[i]*column[i];
        }
        
        for (int j = 0; j < column.length; j++) {
            ratio[j] = column[j]/(Math.pow(quadraticSum, 0.5));
        }       
        return ratio;
    }
    
    public static double distanceValue(double q, double mu1, double nu1, double mu2, double nu2) {
        double distanceValue = 0.0;
        distanceValue = Math.pow(0.5*Math.pow(Math.abs(mu1-mu2), 3.0) + 0.5*Math.pow(Math.abs(nu1-nu2), 3.0), 1.0/3.0);
        //distanceValue = 0.5 * (Math.abs(Math.pow(mu1, q)- Math.pow(mu2, q)) + Math.abs(Math.pow(nu1, q)- Math.pow(nu2, q)) + 
                               //Math.abs((1 - Math.pow(mu1, q) - Math.pow(nu1, q)) - (1 - Math.pow(mu2, q) - Math.pow(nu2, q))));
        return distanceValue;
    }
    
    public static double[] FNpFN(double q, double[] FN1, double[] FN2) {
        double[] FN = {0.0, 0.0};
        FN[0] = Math.pow(Math.pow(FN1[0],q) + Math.pow(FN2[0],q) - Math.pow(FN1[0],q)*Math.pow(FN2[0],q), 1.0/q);
        FN[1] = FN1[1] * FN2[1];
        return FN;
    }
    
    public static double[] FNmFN(double q, double[] FN1, double[] FN2) {
        double[] FN = {0.0, 0.0};
        FN[0] = FN1[0] * FN2[0];
        FN[1] = Math.pow(Math.pow(FN1[1],q) + Math.pow(FN2[1],q) - Math.pow(FN1[1],q)*Math.pow(FN2[1],q), 1.0/q);      
        return FN;
    }
    
    public static double[] RNmFN(double q, double RN, double[] FN) {
        double[] FFNN = {0.0, 0.0};
        FFNN[0] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(FN[0], q), RN), 1.0/q);
        FFNN[1] = Math.pow(FN[1], RN);
        return FFNN;
    }
    
    public static double[] FNpRN(double q, double[] FN, double RN) {
        double[] FFNN = {0.0, 0.0};
        FFNN[0] = Math.pow(FN[0], RN);
        FFNN[1] = Math.pow(1.0 - Math.pow(1.0 - Math.pow(FN[1], q), RN), 1.0/q);        
        return FFNN;
    }
}